import type { Express } from "express";
import type { Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import multer from "multer";
import path from "path";
import express from "express";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup static folder for uploads
  app.use("/uploads", express.static(path.join(process.cwd(), "client/public/uploads")));

  // Multer setup for file uploads
  const uploadStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, path.join(process.cwd(), "client/public/uploads"));
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    },
  });
  const upload = multer({ storage: uploadStorage });

  // Setup Auth first
  setupAuth(app);

  // Upload endpoint
  app.post("/api/upload", (req, res, next) => {
    if (!req.isAuthenticated() || req.user.role !== "ADMIN") {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  }, upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.json({ url: fileUrl });
  });

  // Seed data
  if (await storage.countUsers() === 0) {
    console.log("Seeding database...");
    // Create admin user will be handled by first registration
    // Seed some mods and fusions
    await storage.createMod({
      title: "Fusion Mod v1.0",
      version: "1.0",
      description: "The first version of PvZ Fusion Mod. Includes basic fusions.",
      changelog: "Initial release",
      imageUrl: "https://placehold.co/600x400/4CAF50/FFFFFF?text=Mod+v1.0",
      fileUrl: "#",
    });
    await storage.createFusion({
      name: "Pea-nut",
      type: "Plant",
      recipe: "Peashooter + Wall-nut",
      ability: "Shoots peas and acts as a shield.",
      imageUrl: "https://placehold.co/400x400/4CAF50/FFFFFF?text=Pea-nut",
    });
    await storage.createVideo({
      title: "PvZ Fusion Gameplay #1",
      thumbnailUrl: "https://placehold.co/600x400/FF0000/FFFFFF?text=Video+1",
      youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
      description: "First look at the new fusion plants!",
    });
  }

  // Middleware to check if user is admin
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated() || req.user.role !== "ADMIN") {
      return res.status(403).json({ message: "Forbidden: Admin access required" });
    }
    next();
  };

  // === Mods ===
  app.get(api.mods.list.path, async (req, res) => {
    const mods = await storage.getMods();
    res.json(mods);
  });

  app.get(api.mods.get.path, async (req, res) => {
    const mod = await storage.getMod(Number(req.params.id));
    if (!mod) return res.status(404).json({ message: "Mod not found" });
    res.json(mod);
  });

  app.post(api.mods.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.mods.create.input.parse(req.body);
      const mod = await storage.createMod(input);
      res.status(201).json(mod);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.mods.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.mods.update.input.parse(req.body);
      const mod = await storage.updateMod(Number(req.params.id), input);
      res.json(mod);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(404).json({ message: "Mod not found" });
    }
  });

  app.delete(api.mods.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteMod(Number(req.params.id));
    res.status(204).send();
  });

  // === Fusions ===
  app.get(api.fusions.list.path, async (req, res) => {
    const fusions = await storage.getFusions();
    res.json(fusions);
  });

  app.get(api.fusions.get.path, async (req, res) => {
    const fusion = await storage.getFusion(Number(req.params.id));
    if (!fusion) return res.status(404).json({ message: "Fusion not found" });
    res.json(fusion);
  });

  app.post(api.fusions.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.fusions.create.input.parse(req.body);
      const fusion = await storage.createFusion(input);
      res.status(201).json(fusion);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.fusions.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.fusions.update.input.parse(req.body);
      const fusion = await storage.updateFusion(Number(req.params.id), input);
      res.json(fusion);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(404).json({ message: "Fusion not found" });
    }
  });

  app.delete(api.fusions.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteFusion(Number(req.params.id));
    res.status(204).send();
  });

  // === Videos ===
  app.get(api.videos.list.path, async (req, res) => {
    const videos = await storage.getVideos();
    res.json(videos);
  });

  app.post(api.videos.create.path, requireAdmin, async (req, res) => {
    try {
      const input = api.videos.create.input.parse(req.body);
      const video = await storage.createVideo(input);
      res.status(201).json(video);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.videos.update.path, requireAdmin, async (req, res) => {
    try {
      const input = api.videos.update.input.parse(req.body);
      const video = await storage.updateVideo(Number(req.params.id), input);
      res.json(video);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(404).json({ message: "Video not found" });
    }
  });

  app.delete(api.videos.delete.path, requireAdmin, async (req, res) => {
    await storage.deleteVideo(Number(req.params.id));
    res.status(204).send();
  });

  return httpServer;
}
