import { db } from "./db";
import {
  users, mods, fusions, videos,
  type User, type InsertUser,
  type Mod, type InsertMod,
  type Fusion, type InsertFusion,
  type Video, type InsertVideo
} from "@shared/schema";
import { eq } from "drizzle-orm";

import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  sessionStore: session.Store;
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { role?: "ADMIN" | "USER" }): Promise<User>;
  countUsers(): Promise<number>;

  // Mods
  getMods(): Promise<Mod[]>;
  getMod(id: number): Promise<Mod | undefined>;
  createMod(mod: InsertMod): Promise<Mod>;
  updateMod(id: number, mod: Partial<InsertMod>): Promise<Mod>;
  deleteMod(id: number): Promise<void>;

  // Fusions
  getFusions(): Promise<Fusion[]>;
  getFusion(id: number): Promise<Fusion | undefined>;
  createFusion(fusion: InsertFusion): Promise<Fusion>;
  updateFusion(id: number, fusion: Partial<InsertFusion>): Promise<Fusion>;
  deleteFusion(id: number): Promise<void>;

  // Videos
  getVideos(): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, video: Partial<InsertVideo>): Promise<Video>;
  deleteVideo(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser & { role?: "ADMIN" | "USER" }): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async countUsers(): Promise<number> {
    const result = await db.select({ count: users.id }).from(users);
    return result.length;
  }

  // Mods
  async getMods(): Promise<Mod[]> {
    return await db.select().from(mods).orderBy(mods.createdAt);
  }

  async getMod(id: number): Promise<Mod | undefined> {
    const [mod] = await db.select().from(mods).where(eq(mods.id, id));
    return mod;
  }

  async createMod(insertMod: InsertMod): Promise<Mod> {
    const [mod] = await db.insert(mods).values(insertMod).returning();
    return mod;
  }

  async updateMod(id: number, updates: Partial<InsertMod>): Promise<Mod> {
    const [updated] = await db.update(mods)
      .set(updates)
      .where(eq(mods.id, id))
      .returning();
    return updated;
  }

  async deleteMod(id: number): Promise<void> {
    await db.delete(mods).where(eq(mods.id, id));
  }

  // Fusions
  async getFusions(): Promise<Fusion[]> {
    return await db.select().from(fusions).orderBy(fusions.createdAt);
  }

  async getFusion(id: number): Promise<Fusion | undefined> {
    const [fusion] = await db.select().from(fusions).where(eq(fusions.id, id));
    return fusion;
  }

  async createFusion(insertFusion: InsertFusion): Promise<Fusion> {
    const [fusion] = await db.insert(fusions).values(insertFusion).returning();
    return fusion;
  }

  async updateFusion(id: number, updates: Partial<InsertFusion>): Promise<Fusion> {
    const [updated] = await db.update(fusions)
      .set(updates)
      .where(eq(fusions.id, id))
      .returning();
    return updated;
  }

  async deleteFusion(id: number): Promise<void> {
    await db.delete(fusions).where(eq(fusions.id, id));
  }

  // Videos
  async getVideos(): Promise<Video[]> {
    return await db.select().from(videos).orderBy(videos.createdAt);
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  async updateVideo(id: number, updates: Partial<InsertVideo>): Promise<Video> {
    const [updated] = await db.update(videos)
      .set(updates)
      .where(eq(videos.id, id))
      .returning();
    return updated;
  }

  async deleteVideo(id: number): Promise<void> {
    await db.delete(videos).where(eq(videos.id, id));
  }
}

export const storage = new DatabaseStorage();
