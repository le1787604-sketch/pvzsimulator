## Packages
framer-motion | Essential for gaming aesthetic animations and page transitions
lucide-react | Icon set (already in base but confirming usage)
zod | Schema validation
react-hook-form | Form handling
@hookform/resolvers | Zod resolver for forms

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  gaming: ["var(--font-gaming)"],
}
