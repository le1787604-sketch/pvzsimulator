import { Github, Twitter, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-card/30 py-12 mt-auto">
      <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <h3 className="font-gaming text-primary mb-2">PvZ Fusion</h3>
          <p className="text-muted-foreground text-sm max-w-xs">
            The ultimate community resource for Plants vs Zombies Fusion mods, strategies, and videos.
          </p>
        </div>
        
        <div className="flex gap-4">
          <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary/20 hover:text-primary transition-colors">
            <Youtube className="w-5 h-5" />
          </a>
          <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary/20 hover:text-primary transition-colors">
            <Twitter className="w-5 h-5" />
          </a>
          <a href="#" className="p-2 rounded-full bg-muted hover:bg-primary/20 hover:text-primary transition-colors">
            <Github className="w-5 h-5" />
          </a>
        </div>
      </div>
      <div className="container mx-auto px-4 mt-8 pt-8 border-t border-border/50 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} PvZ Fusion Fan Site. Not affiliated with PopCap or EA.
      </div>
    </footer>
  );
}
