import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Menu, X, LogIn, Gamepad2, Sprout, PlaySquare, Shield } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { api } from "@shared/routes";

const loginSchema = api.auth.login.input;
type LoginForm = z.infer<typeof loginSchema>;

function LoginDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { login, isLoggingIn } = useAuth();
  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = (data: LoginForm) => {
    login(data, {
      onSuccess: () => onOpenChange(false),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary text-center">LOGIN</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="user@example.com" {...register("email")} />
            {errors.email && <p className="text-sm text-destructive">{errors.email.message}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="••••••" {...register("password")} />
            {errors.password && <p className="text-sm text-destructive">{errors.password.message}</p>}
          </div>
          <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-bold" disabled={isLoggingIn}>
            {isLoggingIn ? "Loading..." : "Enter the Lab"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);

  const links = [
    { href: "/", label: "Home", icon: Sprout },
    { href: "/mods", label: "Mods", icon: Gamepad2 },
    { href: "/dex", label: "Fusion Dex", icon: Sprout },
    { href: "/videos", label: "Videos", icon: PlaySquare },
  ];

  const isActive = (path: string) => location === path;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-green-700 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
             <Sprout className="text-white w-6 h-6" />
          </div>
          <span className="font-gaming text-sm md:text-base text-primary tracking-tighter">
            PvZ<span className="text-secondary">Fusion</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <Link key={link.href} href={link.href} className={`
              flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary
              ${isActive(link.href) ? "text-primary font-bold" : "text-muted-foreground"}
            `}>
              <link.icon className="w-4 h-4" />
              {link.label}
            </Link>
          ))}
          
          {user?.role === "ADMIN" && (
            <Link href="/admin" className="text-destructive font-bold flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Admin
            </Link>
          )}
        </nav>

        {/* Auth / Mobile Toggle */}
        <div className="flex items-center gap-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-10 w-10 border-2 border-primary/20">
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} />
                    <AvatarFallback>{user.email[0].toUpperCase()}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <div className="flex flex-col space-y-1 p-2">
                  <p className="text-sm font-medium leading-none">{user.email}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user.role}</p>
                </div>
                <DropdownMenuSeparator />
                {user.role === "ADMIN" && (
                  <Link href="/admin">
                    <DropdownMenuItem className="cursor-pointer">
                      <Shield className="mr-2 h-4 w-4" />
                      Admin Dashboard
                    </DropdownMenuItem>
                  </Link>
                )}
                <DropdownMenuItem className="text-destructive cursor-pointer" onClick={() => logout()}>
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button 
                onClick={() => setLoginOpen(true)} 
                variant="default" 
                className="hidden md:flex bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Login
              </Button>
              <LoginDialog open={loginOpen} onOpenChange={setLoginOpen} />
            </>
          )}

          <Button variant="ghost" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background p-4 space-y-4 animate-in slide-in-from-top-5">
          {links.map((link) => (
            <Link 
              key={link.href} 
              href={link.href} 
              className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted text-foreground"
              onClick={() => setMobileMenuOpen(false)}
            >
              <link.icon className="w-5 h-5 text-primary" />
              {link.label}
            </Link>
          ))}
          {!user && (
            <Button onClick={() => { setLoginOpen(true); setMobileMenuOpen(false); }} className="w-full">
              Login
            </Button>
          )}
        </div>
      )}
    </header>
  );
}
