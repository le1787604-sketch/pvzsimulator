import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertFusion } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useFusions() {
  return useQuery({
    queryKey: [api.fusions.list.path],
    queryFn: async () => {
      const res = await fetch(api.fusions.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch fusions");
      return api.fusions.list.responses[200].parse(await res.json());
    },
  });
}

export function useFusionMutations() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createFusion = useMutation({
    mutationFn: async (data: InsertFusion) => {
      const res = await fetch(api.fusions.create.path, {
        method: api.fusions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create fusion");
      return api.fusions.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.fusions.list.path] });
      toast({ title: "Success", description: "Fusion created successfully" });
    },
  });

  const updateFusion = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<InsertFusion>) => {
      const url = buildUrl(api.fusions.update.path, { id });
      const res = await fetch(url, {
        method: api.fusions.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update fusion");
      return api.fusions.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.fusions.list.path] });
      toast({ title: "Success", description: "Fusion updated successfully" });
    },
  });

  const deleteFusion = useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.fusions.delete.path, { id });
      const res = await fetch(url, {
        method: api.fusions.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete fusion");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.fusions.list.path] });
      toast({ title: "Success", description: "Fusion deleted successfully" });
    },
  });

  return { createFusion, updateFusion, deleteFusion };
}
