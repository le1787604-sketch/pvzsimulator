import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertMod } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useMods() {
  return useQuery({
    queryKey: [api.mods.list.path],
    queryFn: async () => {
      const res = await fetch(api.mods.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch mods");
      return api.mods.list.responses[200].parse(await res.json());
    },
  });
}

export function useMod(id: number) {
  return useQuery({
    queryKey: [api.mods.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.mods.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch mod");
      return api.mods.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useModMutations() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createMod = useMutation({
    mutationFn: async (data: InsertMod) => {
      const res = await fetch(api.mods.create.path, {
        method: api.mods.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create mod");
      return api.mods.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.mods.list.path] });
      toast({ title: "Success", description: "Mod created successfully" });
    },
  });

  const updateMod = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<InsertMod>) => {
      const url = buildUrl(api.mods.update.path, { id });
      const res = await fetch(url, {
        method: api.mods.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update mod");
      return api.mods.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.mods.list.path] });
      toast({ title: "Success", description: "Mod updated successfully" });
    },
  });

  const deleteMod = useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.mods.delete.path, { id });
      const res = await fetch(url, {
        method: api.mods.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete mod");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.mods.list.path] });
      toast({ title: "Success", description: "Mod deleted successfully" });
    },
  });

  return { createMod, updateMod, deleteMod };
}
