import { useAuth } from "@/hooks/use-auth";
import { useMods, useModMutations } from "@/hooks/use-mods";
import { useFusions, useFusionMutations } from "@/hooks/use-fusions";
import { useVideos, useVideoMutations } from "@/hooks/use-videos";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash, Edit, Loader2, Upload } from "lucide-react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertModSchema, insertFusionSchema, insertVideoSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// File Upload Component
function FileUpload({ onUpload, label, accept = "image/*" }: { onUpload: (url: string) => void, label: string, accept?: string }) {
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Upload failed");
      const data = await res.json();
      onUpload(data.url);
      toast({ title: "Success", description: "File uploaded successfully" });
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: "Failed to upload file" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="grid gap-2">
      <Label>{label}</Label>
      <div className="flex items-center gap-2">
        <Input type="file" accept={accept} onChange={handleFileChange} disabled={uploading} className="flex-1" />
        {uploading && <Loader2 className="animate-spin w-4 h-4" />}
      </div>
    </div>
  );
}

// Form Components
function ModForm({ onSubmit, initialData }: { onSubmit: (data: any) => void, initialData?: any }) {
  const { register, handleSubmit, setValue, watch } = useForm({
    defaultValues: initialData,
    resolver: zodResolver(insertModSchema),
  });
  const imageUrl = watch("imageUrl");
  const fileUrl = watch("fileUrl");

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
      <div className="grid gap-2">
        <Label>Title</Label>
        <Input {...register("title")} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label>Version</Label>
          <Input {...register("version")} />
        </div>
        <FileUpload label="Image" onUpload={(url) => setValue("imageUrl", url)} />
      </div>
      {imageUrl && <div className="text-xs text-muted-foreground truncate">Current Image: {imageUrl}</div>}
      
      <FileUpload label="Mod File (.zip, .rar)" accept=".zip,.rar,.7z" onUpload={(url) => setValue("fileUrl", url)} />
      {fileUrl && <div className="text-xs text-muted-foreground truncate">Current File: {fileUrl}</div>}

      <div className="grid gap-2">
        <Label>Description</Label>
        <Textarea {...register("description")} />
      </div>
      <div className="grid gap-2">
        <Label>Changelog</Label>
        <Textarea {...register("changelog")} />
      </div>
      <Button type="submit" className="w-full">Save Mod</Button>
    </form>
  );
}

function FusionForm({ onSubmit, initialData }: { onSubmit: (data: any) => void, initialData?: any }) {
  const { register, handleSubmit, setValue, watch } = useForm({
    defaultValues: initialData,
    resolver: zodResolver(insertFusionSchema),
  });
  const imageUrl = watch("imageUrl");

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label>Name</Label>
          <Input {...register("name")} />
        </div>
        <div className="grid gap-2">
          <Label>Type</Label>
          <Select onValueChange={(val) => setValue("type", val as "Plant" | "Zombie")} defaultValue={initialData?.type}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Plant">Plant</SelectItem>
              <SelectItem value="Zombie">Zombie</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid gap-2">
        <Label>Recipe</Label>
        <Input {...register("recipe")} />
      </div>
      <div className="grid gap-2">
        <Label>Ability</Label>
        <Textarea {...register("ability")} />
      </div>
      <FileUpload label="Image" onUpload={(url) => setValue("imageUrl", url)} />
      {imageUrl && <div className="text-xs text-muted-foreground truncate">Current Image: {imageUrl}</div>}
      
      <div className="grid gap-2">
        <Label>Video URL (Optional)</Label>
        <Input {...register("videoUrl")} />
      </div>
      <Button type="submit" className="w-full">Save Fusion</Button>
    </form>
  );
}

function VideoForm({ onSubmit, initialData }: { onSubmit: (data: any) => void, initialData?: any }) {
  const { register, handleSubmit, setValue, watch } = useForm({
    defaultValues: initialData,
    resolver: zodResolver(insertVideoSchema),
  });
  const thumbnailUrl = watch("thumbnailUrl");

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
      <div className="grid gap-2">
        <Label>Title</Label>
        <Input {...register("title")} />
      </div>
      <div className="grid gap-2">
        <Label>YouTube URL</Label>
        <Input {...register("youtubeUrl")} />
      </div>
      <FileUpload label="Thumbnail" onUpload={(url) => setValue("thumbnailUrl", url)} />
      {thumbnailUrl && <div className="text-xs text-muted-foreground truncate">Current Thumbnail: {thumbnailUrl}</div>}
      
      <div className="grid gap-2">
        <Label>Description</Label>
        <Textarea {...register("description")} />
      </div>
      <Button type="submit" className="w-full">Save Video</Button>
    </form>
  );
}

export default function Admin() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "ADMIN")) {
      setLocation("/");
    }
  }, [user, authLoading, setLocation]);

  const { data: mods } = useMods();
  const { createMod, updateMod, deleteMod } = useModMutations();
  const [modDialogOpen, setModDialogOpen] = useState(false);
  const [editingMod, setEditingMod] = useState<any>(null);

  const { data: fusions } = useFusions();
  const { createFusion, updateFusion, deleteFusion } = useFusionMutations();
  const [fusionDialogOpen, setFusionDialogOpen] = useState(false);
  const [editingFusion, setEditingFusion] = useState<any>(null);

  const { data: videos } = useVideos();
  const { createVideo, updateVideo, deleteVideo } = useVideoMutations();
  const [videoDialogOpen, setVideoDialogOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<any>(null);

  if (authLoading || !user) return <div className="p-20 text-center"><Loader2 className="animate-spin mx-auto w-10 h-10" /></div>;

  return (
    <div className="container px-4 py-8">
      <h1 className="text-3xl font-display mb-8">Admin Dashboard</h1>
      
      <Tabs defaultValue="mods" className="space-y-6">
        <TabsList className="bg-card">
          <TabsTrigger value="mods">Mods</TabsTrigger>
          <TabsTrigger value="fusions">Fusions</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
        </TabsList>

        <TabsContent value="mods">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Manage Mods</CardTitle>
                <CardDescription>Add or update game versions.</CardDescription>
              </div>
              <Button onClick={() => { setEditingMod(null); setModDialogOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" /> Add Mod
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Version</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mods?.map((mod) => (
                    <TableRow key={mod.id}>
                      <TableCell className="font-medium">{mod.title}</TableCell>
                      <TableCell>{mod.version}</TableCell>
                      <TableCell>{new Date(mod.createdAt!).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingMod(mod); setModDialogOpen(true); }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMod.mutate(mod.id)}>
                          <Trash className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
          
          <Dialog open={modDialogOpen} onOpenChange={setModDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>{editingMod ? "Edit Mod" : "Add Mod"}</DialogTitle></DialogHeader>
              <ModForm 
                initialData={editingMod} 
                onSubmit={(data) => {
                  editingMod ? updateMod.mutate({ id: editingMod.id, ...data }) : createMod.mutate(data);
                  setModDialogOpen(false);
                }} 
              />
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="fusions">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Manage Fusions</CardTitle>
                <CardDescription>Database of plant/zombie combinations.</CardDescription>
              </div>
              <Button onClick={() => { setEditingFusion(null); setFusionDialogOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" /> Add Fusion
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Recipe</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fusions?.map((fusion) => (
                    <TableRow key={fusion.id}>
                      <TableCell className="font-medium flex items-center gap-2">
                        <img src={fusion.imageUrl} className="w-8 h-8 rounded object-cover" />
                        {fusion.name}
                      </TableCell>
                      <TableCell>{fusion.type}</TableCell>
                      <TableCell>{fusion.recipe}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingFusion(fusion); setFusionDialogOpen(true); }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteFusion.mutate(fusion.id)}>
                          <Trash className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Dialog open={fusionDialogOpen} onOpenChange={setFusionDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>{editingFusion ? "Edit Fusion" : "Add Fusion"}</DialogTitle></DialogHeader>
              <FusionForm 
                initialData={editingFusion} 
                onSubmit={(data) => {
                  editingFusion ? updateFusion.mutate({ id: editingFusion.id, ...data }) : createFusion.mutate(data);
                  setFusionDialogOpen(false);
                }} 
              />
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="videos">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Manage Videos</CardTitle>
                <CardDescription>Featured gameplay videos.</CardDescription>
              </div>
              <Button onClick={() => { setEditingVideo(null); setVideoDialogOpen(true); }}>
                <Plus className="w-4 h-4 mr-2" /> Add Video
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Link</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {videos?.map((video) => (
                    <TableRow key={video.id}>
                      <TableCell className="font-medium">{video.title}</TableCell>
                      <TableCell className="max-w-[200px] truncate">{video.youtubeUrl}</TableCell>
                      <TableCell className="text-right space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingVideo(video); setVideoDialogOpen(true); }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteVideo.mutate(video.id)}>
                          <Trash className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Dialog open={videoDialogOpen} onOpenChange={setVideoDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>{editingVideo ? "Edit Video" : "Add Video"}</DialogTitle></DialogHeader>
              <VideoForm 
                initialData={editingVideo} 
                onSubmit={(data) => {
                  editingVideo ? updateVideo.mutate({ id: editingVideo.id, ...data }) : createVideo.mutate(data);
                  setVideoDialogOpen(false);
                }} 
              />
            </DialogContent>
          </Dialog>
        </TabsContent>
      </Tabs>
    </div>
  );
}
