import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Download, Play, Zap } from "lucide-react";
import { useMods } from "@/hooks/use-mods";
import { useFusions } from "@/hooks/use-fusions";

export default function Home() {
  const { data: mods } = useMods();
  const { data: fusions } = useFusions();

  const featuredMod = mods?.[0];
  const featuredFusion = fusions?.[0];

  return (
    <div className="flex flex-col gap-16 pb-20">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden pt-20">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background z-0" />
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-secondary/20 rounded-full blur-[100px]" />
        
        <div className="container relative z-10 px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-gaming text-4xl md:text-6xl lg:text-7xl mb-6 text-transparent bg-clip-text bg-gradient-to-br from-primary via-green-400 to-secondary drop-shadow-sm">
              EVOLVE YOUR<br />GARDEN DEFENSE
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-8 font-light">
              Discover crazy plant fusions, download custom mods, and master the chaos of PvZ Fusion.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/mods">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold h-14 px-8 rounded-2xl shadow-lg shadow-primary/25 hover:scale-105 transition-transform">
                  Download Mods <Download className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/dex">
                <Button size="lg" variant="outline" className="border-2 border-primary/50 text-primary hover:bg-primary/10 font-bold h-14 px-8 rounded-2xl hover:scale-105 transition-transform">
                  Browse Dex <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="container px-4">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Featured Mod Card */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative bg-card rounded-3xl overflow-hidden border border-border hover:border-primary/50 transition-colors shadow-xl"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent z-10" />
            
            {/* Descriptive Comment for Unsplash */}
            {/* Video game landscape generic fantasy style */}
            <img 
              src={featuredMod?.imageUrl || "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80"} 
              alt="Featured Mod" 
              className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-700" 
            />
            
            <div className="absolute bottom-0 left-0 p-8 z-20 w-full">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-3 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-full uppercase tracking-wider">
                  Featured Mod
                </span>
                {featuredMod && <span className="text-gray-300 text-xs">{featuredMod.version}</span>}
              </div>
              <h3 className="text-3xl font-display text-white mb-2">{featuredMod?.title || "Fusion Mod v3.0"}</h3>
              <p className="text-gray-300 line-clamp-2 mb-4">
                {featuredMod?.description || "Experience the ultimate fusion mechanics with over 100 new plant combinations."}
              </p>
              <Link href="/mods">
                <Button variant="secondary" className="w-full font-bold">
                  View Details
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Featured Fusion Card */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative bg-card rounded-3xl overflow-hidden border border-border hover:border-secondary/50 transition-colors shadow-xl"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent z-10" />
            
            {/* Descriptive Comment for Unsplash */}
            {/* Close up of exotic weird plant nature macro */}
            <img 
              src={featuredFusion?.imageUrl || "https://images.unsplash.com/photo-1530631339102-e1b92066006f?w=800&q=80"} 
              alt="Featured Fusion" 
              className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-700" 
            />
            
            <div className="absolute bottom-0 left-0 p-8 z-20 w-full">
              <span className="px-3 py-1 bg-secondary text-secondary-foreground text-xs font-bold rounded-full uppercase tracking-wider mb-4 inline-block">
                Fusion Spotlight
              </span>
              <h3 className="text-3xl font-display text-white mb-2">{featuredFusion?.name || "Peashooter + Torchwood"}</h3>
              <div className="flex items-center gap-2 text-yellow-300 mb-4">
                <Zap className="w-4 h-4 fill-current" />
                <span className="font-bold">{featuredFusion?.ability || "Fires flaming peas that splash damage"}</span>
              </div>
              <Link href="/dex">
                <Button variant="secondary" className="w-full font-bold">
                  Explore Dex
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="container px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Active Mods", value: "24" },
            { label: "Fusions", value: "150+" },
            { label: "Community", value: "12k" },
            { label: "Downloads", value: "1.5M" },
          ].map((stat, i) => (
            <div key={i} className="bg-card/50 border border-border rounded-2xl p-6 text-center">
              <div className="text-3xl md:text-4xl font-gaming text-primary mb-2">{stat.value}</div>
              <div className="text-muted-foreground text-sm uppercase tracking-widest">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
