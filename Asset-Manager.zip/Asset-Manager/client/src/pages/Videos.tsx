import { useVideos } from "@/hooks/use-videos";
import { motion } from "framer-motion";
import { Play } from "lucide-react";

export default function Videos() {
  const { data: videos, isLoading } = useVideos();

  if (isLoading) return <div className="text-center py-20">Loading...</div>;

  return (
    <div className="container px-4 py-12">
      <div className="text-center mb-16">
        <h1 className="font-gaming text-3xl md:text-5xl text-red-500 mb-4 text-shadow">GAMEPLAY</h1>
        <p className="text-muted-foreground">Watch the craziest fusions in action.</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {videos?.map((video, index) => (
          <motion.div
            key={video.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="group bg-card rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all"
          >
            <a href={video.youtubeUrl} target="_blank" rel="noopener noreferrer" className="block relative aspect-video">
              <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 text-white fill-current ml-1" />
                </div>
              </div>
            </a>
            <div className="p-4">
              <h3 className="font-bold text-lg leading-tight mb-2 group-hover:text-red-400 transition-colors">{video.title}</h3>
              {video.description && (
                <p className="text-sm text-muted-foreground line-clamp-2">{video.description}</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
