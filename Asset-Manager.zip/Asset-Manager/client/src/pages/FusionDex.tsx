import { useFusions } from "@/hooks/use-fusions";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Zap, FlaskConical } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export default function FusionDex() {
  const { data: fusions, isLoading } = useFusions();
  const [search, setSearch] = useState("");
  const [selectedFusion, setSelectedFusion] = useState<typeof fusions extends (infer U)[] ? U : never | null>(null);

  const filtered = fusions?.filter(f => 
    f.name.toLowerCase().includes(search.toLowerCase()) || 
    f.recipe.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container px-4 py-12">
      <div className="flex flex-col items-center mb-12">
        <h1 className="font-gaming text-3xl md:text-5xl text-secondary mb-6 text-shadow">FUSION DEX</h1>
        
        <div className="relative w-full max-w-lg">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input 
            className="pl-12 h-14 rounded-full bg-card/50 border-primary/20 focus:border-primary text-lg" 
            placeholder="Search plant or zombie..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="aspect-square bg-card/30 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          <AnimatePresence>
            {filtered?.map((fusion) => (
              <motion.div
                key={fusion.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                onClick={() => setSelectedFusion(fusion)}
                className="cursor-pointer group relative aspect-square bg-card rounded-2xl border-2 border-transparent hover:border-primary/50 overflow-hidden shadow-lg transition-all hover:-translate-y-2"
              >
                <img 
                  src={fusion.imageUrl} 
                  alt={fusion.name} 
                  className="w-full h-full object-cover p-4 group-hover:scale-110 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                  <span className="text-white font-bold text-sm text-center w-full">
                    {fusion.name}
                  </span>
                </div>
                <Badge className={`absolute top-2 right-2 ${fusion.type === 'Plant' ? 'bg-green-600' : 'bg-purple-600'}`}>
                  {fusion.type}
                </Badge>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!selectedFusion} onOpenChange={(open) => !open && setSelectedFusion(null)}>
        <DialogContent className="bg-card border-border max-w-2xl">
          {selectedFusion && (
            <div className="grid md:grid-cols-2 gap-6">
              <div className="relative aspect-square rounded-xl overflow-hidden bg-black/20 p-8 flex items-center justify-center">
                 <img src={selectedFusion.imageUrl} alt={selectedFusion.name} className="max-w-full max-h-full object-contain drop-shadow-2xl" />
              </div>
              
              <div>
                <DialogHeader className="mb-6">
                  <DialogTitle className="text-3xl font-display text-primary">{selectedFusion.name}</DialogTitle>
                  <DialogDescription className="text-lg text-muted-foreground flex items-center gap-2">
                    <FlaskConical className="w-5 h-5 text-secondary" />
                    Recipe: <span className="text-foreground font-bold">{selectedFusion.recipe}</span>
                  </DialogDescription>
                </DialogHeader>

                <div className="space-y-6">
                  <div className="bg-accent/10 p-4 rounded-xl border border-accent/20">
                    <h4 className="text-accent font-bold flex items-center gap-2 mb-2">
                      <Zap className="w-4 h-4" /> Ability
                    </h4>
                    <p className="text-sm md:text-base leading-relaxed">
                      {selectedFusion.ability}
                    </p>
                  </div>

                  {selectedFusion.videoUrl && (
                    <Button variant="outline" className="w-full" onClick={() => window.open(selectedFusion.videoUrl!, '_blank')}>
                      Watch Demo Video
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
