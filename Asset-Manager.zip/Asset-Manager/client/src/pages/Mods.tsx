import { useMods } from "@/hooks/use-mods";
import { Button } from "@/components/ui/button";
import { Download, Calendar, Info } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function Mods() {
  const { data: mods, isLoading } = useMods();

  if (isLoading) {
    return (
      <div className="container px-4 py-20 text-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <h2 className="text-2xl font-gaming text-muted-foreground">Loading Mods...</h2>
      </div>
    );
  }

  return (
    <div className="container px-4 py-12">
      <div className="text-center mb-16">
        <h1 className="font-gaming text-3xl md:text-5xl text-primary mb-4">MOD LIBRARY</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Download the latest versions of Plants vs Zombies Fusion. All mods are community verified.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {mods?.map((mod, index) => (
          <motion.div
            key={mod.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="group bg-card rounded-2xl overflow-hidden border border-border shadow-lg hover:shadow-primary/20 hover:border-primary/50 transition-all duration-300"
          >
            <div className="relative h-48 overflow-hidden">
              <div className="absolute top-2 right-2 bg-black/70 backdrop-blur text-white text-xs px-2 py-1 rounded font-mono z-10">
                v{mod.version}
              </div>
              <img 
                src={mod.imageUrl} 
                alt={mod.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
            </div>

            <div className="p-6">
              <h3 className="text-xl font-display mb-2 text-foreground group-hover:text-primary transition-colors">
                {mod.title}
              </h3>
              <p className="text-muted-foreground text-sm line-clamp-3 mb-6">
                {mod.description}
              </p>

              <div className="flex items-center justify-between text-xs text-muted-foreground mb-6">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {format(new Date(mod.createdAt || new Date()), 'MMM d, yyyy')}
                </div>
              </div>

              <div className="flex gap-2">
                <Button className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold group-hover:-translate-y-1 transition-transform" onClick={() => window.open(mod.fileUrl, '_blank')}>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                {mod.changelog && (
                  <Button variant="outline" size="icon" title="Changelog">
                    <Info className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        ))}

        {mods?.length === 0 && (
          <div className="col-span-full text-center py-20 text-muted-foreground">
            No mods found. Check back later!
          </div>
        )}
      </div>
    </div>
  );
}
