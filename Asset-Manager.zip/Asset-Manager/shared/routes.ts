import { z } from 'zod';
import { insertUserSchema, insertModSchema, insertFusionSchema, insertVideoSchema, mods, fusions, videos, users } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/login' as const,
      input: z.object({
        email: z.string().email(),
        password: z.string().min(6),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout' as const,
      responses: {
        200: z.void(),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.null(),
      },
    },
    upload: {
      method: 'POST' as const,
      path: '/api/upload' as const,
      responses: {
        200: z.object({ url: z.string() }),
        400: z.object({ message: z.string() }),
        403: z.object({ message: z.string() }),
      },
    },
  },
  mods: {
    list: {
      method: 'GET' as const,
      path: '/api/mods' as const,
      responses: {
        200: z.array(z.custom<typeof mods.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/mods/:id' as const,
      responses: {
        200: z.custom<typeof mods.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/mods' as const,
      input: insertModSchema,
      responses: {
        201: z.custom<typeof mods.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/mods/:id' as const,
      input: insertModSchema.partial(),
      responses: {
        200: z.custom<typeof mods.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/mods/:id' as const,
      responses: {
        204: z.void(),
      },
    },
  },
  fusions: {
    list: {
      method: 'GET' as const,
      path: '/api/fusions' as const,
      responses: {
        200: z.array(z.custom<typeof fusions.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/fusions/:id' as const,
      responses: {
        200: z.custom<typeof fusions.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/fusions' as const,
      input: insertFusionSchema,
      responses: {
        201: z.custom<typeof fusions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/fusions/:id' as const,
      input: insertFusionSchema.partial(),
      responses: {
        200: z.custom<typeof fusions.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/fusions/:id' as const,
      responses: {
        204: z.void(),
      },
    },
  },
  videos: {
    list: {
      method: 'GET' as const,
      path: '/api/videos' as const,
      responses: {
        200: z.array(z.custom<typeof videos.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/videos' as const,
      input: insertVideoSchema,
      responses: {
        201: z.custom<typeof videos.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/videos/:id' as const,
      input: insertVideoSchema.partial(),
      responses: {
        200: z.custom<typeof videos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/videos/:id' as const,
      responses: {
        204: z.void(),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
