import { pgTable, text, serial, integer, boolean, timestamp, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["ADMIN", "USER"] }).default("USER").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const mods = pgTable("mods", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  version: text("version").notNull(),
  description: text("description").notNull(),
  changelog: text("changelog"),
  imageUrl: text("image_url").notNull(),
  fileUrl: text("file_url").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const fusions = pgTable("fusions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type", { enum: ["Plant", "Zombie"] }).notNull(),
  recipe: text("recipe").notNull(),
  ability: text("ability").notNull(),
  imageUrl: text("image_url").notNull(),
  fileUrl: text("file_url"), // Optional
  videoUrl: text("video_url"), // Optional
  createdAt: timestamp("created_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  youtubeUrl: text("youtube_url").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, role: true });
export const insertModSchema = createInsertSchema(mods).omit({ id: true, createdAt: true });
export const insertFusionSchema = createInsertSchema(fusions).omit({ id: true, createdAt: true });
export const insertVideoSchema = createInsertSchema(videos).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Mod = typeof mods.$inferSelect;
export type InsertMod = z.infer<typeof insertModSchema>;
export type Fusion = typeof fusions.$inferSelect;
export type InsertFusion = z.infer<typeof insertFusionSchema>;
export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
